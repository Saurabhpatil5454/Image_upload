from django.apps import AppConfig


class AppImageConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app_image'
